# Socio-launcher🔮
* its a browser extension to easy access to your social handles 
* Preview :-
* ![Screenshot 2021-09-13 134152](https://user-images.githubusercontent.com/78024790/133047760-e02d3afd-1ee5-43ed-9607-cafb0f8945e6.png)


